install.packages("rpart.plot")
install.packages("ROCR")
install.packages("party")
library(rpart)
library(rpart.plot)
library(ROCR)
library(party)

setwd("C:/Users/Mushtaq/Downloads/ADS/midterm/BlogFeedback")
blogtrain<-read.csv("blogData_train.csv",header = T)
summary(is.na(blogtrain))


#Creating test data
blogtest1<-read.csv("blogData_test-2012.02.01.00_00.csv",header=T)
blogtest2<-read.csv("blogData_test-2012.02.02.00_00.csv",header=T)
names(blogtest2)<-names(blogtest1)
blogtest3<-read.csv("blogData_test-2012.02.03.00_00.csv",header=T)
names(blogtest3)<-names(blogtest1)
blogtest4<-read.csv("blogData_test-2012.02.04.00_00.csv",header=T)
names(blogtest4)<-names(blogtest1)
blogtest5<-read.csv("blogData_test-2012.02.05.00_00.csv",header=T)
names(blogtest5)<-names(blogtest1)
blogtest6<-read.csv("blogData_test-2012.02.06.00_00.csv",header=T)
names(blogtest6)<-names(blogtest1)
blogtest7<-read.csv("blogData_test-2012.02.07.00_00.csv",header=T)
names(blogtest7)<-names(blogtest1)
blogtest8<-read.csv("blogData_test-2012.02.08.00_00.csv",header=T)
names(blogtest8)<-names(blogtest1)
blogtest9<-read.csv("blogData_test-2012.02.09.00_00.csv",header=T)
names(blogtest9)<-names(blogtest1)
blogtest10<-read.csv("blogData_test-2012.02.10.00_00.csv",header=T)
names(blogtest10)<-names(blogtest1)
blogtest11<-read.csv("blogData_test-2012.02.11.00_00.csv",header=T)
names(blogtest11)<-names(blogtest1)
blogtest12<-read.csv("blogData_test-2012.02.12.00_00.csv",header=T)
names(blogtest12)<-names(blogtest1)
blogtest13<-read.csv("blogData_test-2012.02.13.00_00.csv",header=T)
names(blogtest13)<-names(blogtest1)
blogtest14<-read.csv("blogData_test-2012.02.14.00_00.csv",header=T)
names(blogtest14)<-names(blogtest1)
blogtest15<-read.csv("blogData_test-2012.02.15.00_00.csv",header=T)
names(blogtest15)<-names(blogtest1)
blogtest16<-read.csv("blogData_test-2012.02.16.00_00.csv",header=T)
names(blogtest16)<-names(blogtest1)
blogtest17<-read.csv("blogData_test-2012.02.17.00_00.csv",header=T)
names(blogtest17)<-names(blogtest1)
blogtest18<-read.csv("blogData_test-2012.02.18.00_00.csv",header=T)
names(blogtest18)<-names(blogtest1)
blogtest19<-read.csv("blogData_test-2012.02.19.00_00.csv",header=T)
names(blogtest19)<-names(blogtest1)
blogtest20<-read.csv("blogData_test-2012.02.20.00_00.csv",header=T)
names(blogtest20)<-names(blogtest1)
blogtest21<-read.csv("blogData_test-2012.02.21.00_00.csv",header=T)
names(blogtest21)<-names(blogtest1)
blogtest22<-read.csv("blogData_test-2012.02.22.00_00.csv",header=T)
names(blogtest22)<-names(blogtest1)
blogtest23<-read.csv("blogData_test-2012.02.23.00_00.csv",header=T)
names(blogtest23)<-names(blogtest1)
blogtest24<-read.csv("blogData_test-2012.02.24.00_00.csv",header=T)
names(blogtest24)<-names(blogtest1)
blogtest25<-read.csv("blogData_test-2012.02.25.00_00.csv",header=T)
names(blogtest25)<-names(blogtest1)
blogtest26<-read.csv("blogData_test-2012.02.26.00_00.csv",header=T)
names(blogtest26)<-names(blogtest1)
blogtest27<-read.csv("blogData_test-2012.02.27.00_00.csv",header=T)
names(blogtest27)<-names(blogtest1)
blogtest28<-read.csv("blogData_test-2012.02.28.00_00.csv",header=T)
names(blogtest28)<-names(blogtest1)
blogtest29<-read.csv("blogData_test-2012.02.29.00_00.csv",header=T)
names(blogtest29)<-names(blogtest1)
blogtest30<-read.csv("blogData_test-2012.03.01.00_00.csv",header=T)
names(blogtest30)<-names(blogtest1)
blogtest31<-read.csv("blogData_test-2012.03.02.00_00.csv",header=T)
names(blogtest31)<-names(blogtest1)
blogtest32<-read.csv("blogData_test-2012.03.03.00_00.csv",header=T)
names(blogtest32)<-names(blogtest1)
blogtest33<-read.csv("blogData_test-2012.03.04.00_00.csv",header=T)
names(blogtest33)<-names(blogtest1)
blogtest34<-read.csv("blogData_test-2012.03.05.00_00.csv",header=T)
names(blogtest34)<-names(blogtest1)
blogtest35<-read.csv("blogData_test-2012.03.06.00_00.csv",header=T)
names(blogtest35)<-names(blogtest1)
blogtest36<-read.csv("blogData_test-2012.03.07.00_00.csv",header=T)
names(blogtest36)<-names(blogtest1)
blogtest37<-read.csv("blogData_test-2012.03.08.00_00.csv",header=T)
names(blogtest37)<-names(blogtest1)
blogtest38<-read.csv("blogData_test-2012.03.09.00_00.csv",header=T)
names(blogtest38)<-names(blogtest1)
blogtest39<-read.csv("blogData_test-2012.03.10.00_00.csv",header=T)
names(blogtest39)<-names(blogtest1)
blogtest40<-read.csv("blogData_test-2012.03.11.00_00.csv",header=T)
names(blogtest40)<-names(blogtest1)
blogtest41<-read.csv("blogData_test-2012.03.12.00_00.csv",header=T)
names(blogtest41)<-names(blogtest1)
blogtest42<-read.csv("blogData_test-2012.03.13.00_00.csv",header=T)
names(blogtest42)<-names(blogtest1)
blogtest43<-read.csv("blogData_test-2012.03.14.00_00.csv",header=T)
names(blogtest43)<-names(blogtest1)
blogtest44<-read.csv("blogData_test-2012.03.15.00_00.csv",header=T)
names(blogtest44)<-names(blogtest1)
blogtest45<-read.csv("blogData_test-2012.03.16.00_00.csv",header=T)
names(blogtest45)<-names(blogtest1)
blogtest46<-read.csv("blogData_test-2012.03.17.00_00.csv",header=T)
names(blogtest46)<-names(blogtest1)
blogtest47<-read.csv("blogData_test-2012.03.18.00_00.csv",header=T)
names(blogtest47)<-names(blogtest1)
blogtest48<-read.csv("blogData_test-2012.03.19.00_00.csv",header=T)
names(blogtest48)<-names(blogtest1)
blogtest49<-read.csv("blogData_test-2012.03.20.00_00.csv",header=T)
names(blogtest49)<-names(blogtest1)
blogtest50<-read.csv("blogData_test-2012.03.21.00_00.csv",header=T)
names(blogtest50)<-names(blogtest1)
blogtest51<-read.csv("blogData_test-2012.03.22.00_00.csv",header=T)
names(blogtest51)<-names(blogtest1)
blogtest52<-read.csv("blogData_test-2012.03.23.00_00.csv",header=T)
names(blogtest52)<-names(blogtest1)
blogtest53<-read.csv("blogData_test-2012.03.24.00_00.csv",header=T)
names(blogtest53)<-names(blogtest1)
blogtest54<-read.csv("blogData_test-2012.03.25.00_00.csv",header=T)
names(blogtest54)<-names(blogtest1)
blogtest55<-read.csv("blogData_test-2012.03.26.01_00.csv",header=T)
names(blogtest55)<-names(blogtest1)
blogtest56<-read.csv("blogData_test-2012.03.27.01_00.csv",header=T)
names(blogtest56)<-names(blogtest1)
blogtest57<-read.csv("blogData_test-2012.03.28.01_00.csv",header=T)
names(blogtest57)<-names(blogtest1)
blogtest58<-read.csv("blogData_test-2012.03.29.01_00.csv",header=T)
names(blogtest58)<-names(blogtest1)
blogtest59<-read.csv("blogData_test-2012.03.30.01_00.csv",header=T)
names(blogtest59)<-names(blogtest1)
blogtest60<-read.csv("blogData_test-2012.03.31.01_00.csv",header=T)
names(blogtest60)<-names(blogtest1)

blogtest<-rbind(blogtest1,blogtest2,blogtest3,blogtest4,blogtest5,blogtest6,blogtest7,blogtest8,blogtest9,blogtest10,blogtest11,blogtest12,blogtest13,blogtest14,blogtest15,blogtest16,blogtest17,blogtest18,blogtest19,blogtest20,blogtest21,blogtest22,blogtest23,blogtest24,blogtest25,blogtest26,blogtest27,blogtest28,blogtest29,blogtest30,blogtest31,blogtest32,blogtest33,blogtest34,blogtest35,blogtest36,blogtest37,blogtest38,blogtest39,blogtest40,blogtest41,blogtest42,blogtest43,blogtest44,blogtest45,blogtest46,blogtest47,blogtest48,blogtest49,blogtest50,blogtest51,blogtest52,blogtest53,blogtest54,blogtest55,blogtest56,blogtest57,blogtest58,blogtest59,blogtest60)
names(blogtest)<-names(blogtrain)

#basic
blogtrain_basic<-blogtrain[,c(51:60,281)]
blogtest_basic<-blogtest[,c(51:60,281)]

tree_basic<-rpart(blogtrain_basic$X1.0.2~.,data=blogtrain_basic, method = "anova",control=rpart.control(cp=0.001))
printcp(tree_basic)

bestcp_basic <-tree_basic$cptable[which.min(tree_basic$cptable[,"xerror"]),"CP"]
bestcp_basic

tree.pruned_basic <- prune(tree_basic, cp=bestcp_basic)
summary(tree.pruned_basic)

pred_basic<-predict(tree.pruned_basic,blogtest_basic,type = "vector")
print(tree.pruned_basic)
blogtrain_basictextual<-blogtrain_basictextual[-c(7565:52396),]

conf.matrix_basic<-table(blogtrain_basic$X1.0.2,pred_basic)
rownames(conf.matrix_basic) <- paste("Actual", rownames(conf.matrix_basic), sep=":")
colnames(conf.matrix_basic) <- paste("Predicted", colnames(conf.matrix_basic), sep=":")
print(conf.matrix_basic)

plot(tree.pruned_basic, main="Regression Tree for basic features")
text(tree.pruned_basic,cex=0.8,use.n=TRUE,xpd=TRUE)
prp(tree.pruned_basic,faclen=0,tweak=1.5,extra=1,main="Regression Tree for basic features")

#R squared value
tmp_basic<-printcp(tree_basic)
rsq.val_basic<-1-tmp_basic[,c(3,4)]
rsq.val_basic<-rsq.val_basic[nrow(rsq.val_basic)]
rsq.val_basic

#basic+weekday
blogtrain_basicweekday<-blogtrain[,c(51:60,270:276,281)]
blogtest_basicweekday<-blogtest[,c(51:60,270:276,281)]

tree_basicweekday<-rpart(blogtrain_basicweekday$X1.0.2~.,data=blogtrain_basicweekday, method = "anova",control=rpart.control(cp=0.001))
printcp(tree_basicweekday)

bestcp_basicweekday <-tree_basicweekday$cptable[which.min(tree_basicweekday$cptable[,"xerror"]),"CP"]
bestcp_basicweekday

tree.pruned_basicweekday <- prune(tree_basicweekday, cp=bestcp_basicweekday)
summary(tree.pruned_basicweekday)

blogtrain_basicweekday<-blogtrain_basicweekday[-c(7565:52396),]
pred_basicweekday<-predict(tree.pruned_basicweekday,blogtest_basicweekday,type = "vector")
print(tree.pruned_basicweekday)

conf.matrix_basicweekday<-table(blogtrain_basicweekday$X1.0.2,pred_basicweekday)
rownames(conf.matrix_basicweekday) <- paste("Actual", rownames(conf.matrix_basicweekday), sep=":")
colnames(conf.matrix_basicweekday) <- paste("Predicted", colnames(conf.matrix_basicweekday), sep=":")
print(conf.matrix_basic)

plot(tree.pruned_basicweekday, main="Regression Tree for basic and weekday features")
text(tree.pruned_basicweekday,cex=0.8,use.n=TRUE,xpd=TRUE)
prp(tree.pruned_basicweekday,faclen=0,tweak=1.5,extra=1,main="Regression Tree for basic and weekday features")

#R squared value
tmp_basicweekday<-printcp(tree_basicweekday)
rsq.val_basicweekday<-1-tmp_basicweekday[,c(3,4)]
rsq.val_basicweekday<-rsq.val_basicweekday[nrow(rsq.val_basicweekday)]
rsq.val_basicweekday

#basic+textual
blogtrain_basictextual<-blogtrain[,c(51:60,281)]
blogtest_basictextual<-blogtest[,c(51:60,63:262,281)]

tree_basictextual<-rpart(blogtrain_basictextual$X1.0.2~.,data=blogtrain_basictextual, method = "anova",control=rpart.control(cp=0.001))
printcp(tree_basictextual)

bestcp_basictextual <-tree_basictextual$cptable[which.min(tree_basictextual$cptable[,"xerror"]),"CP"]
bestcp_basictextual

tree.pruned_basictextual <- prune(tree_basictextual, cp=bestcp_basictextual)
summary(tree.pruned_basictextual)

blogtrain_basictextual<-blogtrain_basictextual[-c(7565:52396),]
pred_basictextual<-predict(tree.pruned_basictextual,blogtest_basictextual,type = "vector")
print(tree.pruned_basictextual)

conf.matrix_basictextual<-table(blogtrain_basictextual$X1.0.2,pred_basictextual)
rownames(conf.matrix_basictextual) <- paste("Actual", rownames(conf.matrix_basictextual), sep=":")
colnames(conf.matrix_basictextual) <- paste("Predicted", colnames(conf.matrix_basictextual), sep=":")
print(conf.matrix_basic)

plot(tree.pruned_basic, main="Regression Tree for basic and textual features")
text(tree.pruned_basic,cex=0.8,use.n=TRUE,xpd=TRUE)
prp(tree.pruned_basic,faclen=0,tweak=1.5,extra=1,main="Regression Tree for basic and textual features")

#R squared value
tmp_basictextual<-printcp(tree_basictextual)
rsq.val_basictextual<-1-tmp_basictextual[,c(3,4)]
rsq.val_basictextual<-rsq.val_basictextual[nrow(rsq.val_basictextual)]
rsq.val_basictextual